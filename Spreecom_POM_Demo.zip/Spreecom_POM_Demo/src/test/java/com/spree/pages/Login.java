package com.spree.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
	private WebDriver driver;
	private String username = "ana@spree.com";
	private String password = "ana123" ;
	
	public Login(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "account-button")
	WebElement accountbtn;
	
	@FindBy(name = "spree_user[email]")
	WebElement email;
	
	@FindBy(id = "spree_user_password")
	WebElement pass;
	
	@FindBy(xpath ="//a[normalize-space()='LOGIN']")
	WebElement logIn;
	
	@FindBy(xpath ="//a[normalize-space()='LOGOUT']")
	WebElement logOut;
	
	@FindBy(xpath = "//span[normalize-space()='Signed out successfully.']")
	WebElement logOutFlag;
	
	@FindBy(name = "commit")
	WebElement logInBtn;
	
	@FindBy(xpath = "//span[normalize-space()='Logged in successfully']")
	WebElement validFlag;
	
	@FindBy(xpath = "//h3[normalize-space()='My Account']")
	WebElement title;
	
	@FindBy(xpath = "//span[normalize-space()='Invalid email or password.']") 
	WebElement invalidFlag;
	
	@FindBy(xpath = "//a[normalize-space()='Forgot password?']")
	WebElement forgotPassBtn;
	
	@FindBy(xpath = "//h3[normalize-space()='Forgot password?']")
	WebElement forgotPassTitle;
	
	@FindBy(name = "commit")
	WebElement resetBtn;
	
	//main[@id='content']//li[1]
	@FindBy(xpath = "//main[@id='content']//li[1]")
	WebElement emptyFlag;
	
	@FindBy(className = "spree-checkbox")
	WebElement rememberBox;
	
	@FindBy(xpath = "//a[text()='Sign Up']")
	WebElement noAccountSignUp;
	
	
	//h3[@class='spree-mb-large spree-mt-large spree-header']
	
	public boolean clickLogInButton() throws InterruptedException {
		Thread.sleep(3000);
		accountbtn.click();
		Thread.sleep(2000);
		logIn.click();
		return driver.getCurrentUrl().equals("http://demo.spreecommerce.org/login");
	}

	public boolean logIntoAccount() throws InterruptedException {
		Thread.sleep(3000);
		email.sendKeys(username);
		Thread.sleep(3000);
		pass.sendKeys(password);
		rememberBox.click();
		Thread.sleep(3000);
		logInBtn.click();
		return driver.getCurrentUrl().equals("http://demo.spreecommerce.org/account");
	}
	
	public boolean successfulLoginFlag() {
		return validFlag.isDisplayed();
	}
	
	public boolean successfulLoginTitle() {
		return title.isDisplayed();
	}
	
	public boolean clickLogOutButton() throws InterruptedException {
		Thread.sleep(3000);
		accountbtn.click();
		Thread.sleep(2000);
		logOut.click();
		return driver.getCurrentUrl().equals("http://demo.spreecommerce.org/login");
	}
	
	public boolean clickLogOutFlag() throws InterruptedException {
		Thread.sleep(2000);
		return logOutFlag.isDisplayed();
	}
	
	public boolean noAccountSignUpClick() throws InterruptedException {
		Thread.sleep(2000);
		noAccountSignUp.click();
		return driver.getCurrentUrl().equals("http://demo.spreecommerce.org/signup");
	}
	
	public boolean emptyCredentials() throws InterruptedException {
		Thread.sleep(3000);
		accountbtn.click();
		Thread.sleep(2000);
		logIn.click();
		Thread.sleep(3000);
		logInBtn.click();
		return invalidFlag.isDisplayed();
	}
	
	public boolean incorrectCredentials() throws InterruptedException {
		Thread.sleep(3000);
		accountbtn.click();
		Thread.sleep(2000);
		logIn.click();
		Thread.sleep(3000);
		email.sendKeys(username);
		Thread.sleep(3000);
		pass.sendKeys("incorrectPassword");
		logInBtn.click();
		return invalidFlag.isDisplayed();
	}
	
	public boolean clickForgotPasswordBtn() throws InterruptedException {
		Thread.sleep(3000);
		forgotPassBtn.click();
		return driver.getCurrentUrl().equals("http://demo.spreecommerce.org/password/recover");
	}
	
	public boolean forgotPasswordTitle() throws InterruptedException {
		Thread.sleep(3000);
		return forgotPassTitle.isDisplayed();
	}
	
	public boolean emptyCredentialsForgotPass() throws InterruptedException {
		Thread.sleep(2000);
		resetBtn.click();
		Thread.sleep(2000);
		return emptyFlag.isDisplayed();
	}
	
	
	/*public boolean successfulForgotPass() throws InterruptedException {
		Thread.sleep(2000);
		email.sendKeys(username);
		resetBtn.click();
		Thread.sleep(2000);
		return emptyFlag.isDisplayed();
	}*/
}
	