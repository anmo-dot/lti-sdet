package com.spree.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CheckOut {
	private WebDriver driver;
	private String username = "ana@spree.com";
	private String password = "ana123" ;
	
	@FindBy(id = "account-button")
	WebElement accountbtn;
	
	@FindBy(name = "spree_user[email]")
	WebElement email;
	
	@FindBy(id = "spree_user_password")
	WebElement pass;
	
	@FindBy(xpath ="//a[normalize-space()='LOGIN']")
	WebElement logIn;
	
	@FindBy(name = "commit")
	WebElement logInBtn;
	
	@FindBy(xpath ="//a[normalize-space()='Women']")
	WebElement women;
	
	@FindBy(className = "product-component-name")
	WebElement item;
	
	@FindBy(xpath = "//button[@id='add-to-cart-button']")
	WebElement addToCart;
	
	@FindBy(xpath ="//a[normalize-space()='Checkout']")
	WebElement checkOutBtn;
	
	@FindBy(xpath = "//h1[normalize-space()='Checkout']")
	WebElement title;
	
	@FindBy(name = "commit")
	WebElement saveAndContinue;
	
	@FindBy(id = "name_on_card")
	WebElement cardName;
	
	@FindBy(id = "card_number")
	WebElement cardNum;
	
	@FindBy(id = "card_expiry")
	WebElement cardExp;
	
	@FindBy(id = "card_code")
	WebElement cardCode;
	
	@FindBy(name = "commit")
	WebElement placeOrder;
	
	@FindBy(xpath = "//span[normalize-space()='Bogus Gateway: Forced failure']") 
	WebElement completeFlag;
	
	@FindBy(xpath = "//div[@id='billing_address_106491']//a[@class='ml-1 d-inline-block']//*[name()='svg']//*[name()='path' and contains(@d,'m15.536 12')]")
	WebElement editBillingAddy;
	
	@FindBy(name = "commit")
	WebElement updateBtn;
	
	@FindBy(xpath = "//h3[normalize-space()='Edit Address']")
	WebElement titleEdit;
	
	@FindBy(className = "spree-checkbox")
	WebElement editShippingAddy;
	
	@FindBy(xpath = "//span[normalize-space()='UPS Two Day (USD)']")
	WebElement upsTwoDays;
	
	@FindBy(xpath = "//label[normalize-space()='Check']//span[@class='spree-radio-label-custom-input']")
	WebElement checkPayment;
	
	@FindBy(xpath = "//h5[normalize-space()='Order placed successfully']")
	WebElement validOrderTitle;
	
	@FindBy(xpath="//a[@class='text-uppercase truncate checkout-header-link-text']")
	WebElement cart;
	
	@FindBy(id = "checkout-link")
	WebElement cart_checkout;
	
	//label[normalize-space()='Check']//span[@class='spree-radio-label-custom-input']
	
	@FindBy(xpath = "//label[normalize-space()='Check']//span[@class='spree-radio-label-custom-input']")
	WebElement cartCheck;
	
	public CheckOut(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public boolean SetUpAccount() throws InterruptedException {
		accountbtn.click();
		Thread.sleep(2000);
		logIn.click();
		Thread.sleep(2000);
		email.sendKeys(username);
		pass.sendKeys(password);
		logInBtn.click();
		women.click();
		Thread.sleep(3000);
		item.click();
		Thread.sleep(3000);
		addToCart.click();
		Thread.sleep(3000);
		checkOutBtn.click();
		return driver.getCurrentUrl().equals("http://demo.spreecommerce.org/checkout");
	}
	
	public boolean checkPage() throws InterruptedException {
		Thread.sleep(2000);
		return title.isDisplayed() && driver.getCurrentUrl().equals("http://demo.spreecommerce.org/checkout");
	}
	
	public boolean editShippingAddress() throws InterruptedException {
		Thread.sleep(3000);
		editShippingAddy.click();
		Thread.sleep(2000);
		return !editShippingAddy.isSelected();
	}
	
	public boolean editBillingAddress() throws InterruptedException {
		Thread.sleep(3000);
		editBillingAddy.click();
		Thread.sleep(2000);
		return titleEdit.isDisplayed();
	}
	
	public boolean checkAddressSubmit() throws InterruptedException {
		Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,800)");
		Thread.sleep(3000);
		updateBtn.click();
		Thread.sleep(3000);
		saveAndContinue.click();
		return driver.getCurrentUrl().equals("http://demo.spreecommerce.org/checkout/delivery");
	}
	
	public boolean chooseDeliverMethod() throws InterruptedException {
		upsTwoDays.click();
		Thread.sleep(3000);
		return upsTwoDays.isEnabled();
	}
	
	public boolean checkDeliverySubmit() throws InterruptedException {
		Thread.sleep(2000);
		saveAndContinue.click();
		return driver.getCurrentUrl().equals("http://demo.spreecommerce.org/checkout/payment");
	}
	
	public boolean checkPaymentSubmit() throws InterruptedException {
		Thread.sleep(2000);
		cardName.clear();
		cardName.sendKeys("Ana Diaz");
		cardNum.clear();
		cardNum.sendKeys("4758923475902375");
		cardExp.clear();
		cardExp.sendKeys("102023");
		cardCode.clear();
		cardCode.sendKeys("123");
		saveAndContinue.click();
		return driver.getCurrentUrl().equals("http://demo.spreecommerce.org/checkout/confirm");
	}
	
	public boolean checkConfirmSubmit() throws InterruptedException {
		Thread.sleep(2000);
		placeOrder.click();
		return completeFlag.isDisplayed();
	}
	public boolean checkPaymentCheck() throws InterruptedException {
		checkPayment.click();
		Thread.sleep(3000);
		return checkPayment.isSelected();
	}
	
	public boolean completeCheckPayment() throws InterruptedException {
		saveAndContinue.click();
		Thread.sleep(2000);
		return validOrderTitle.isDisplayed();
	}
	
	public boolean cartClick() throws InterruptedException {
		Thread.sleep(2000);
		cart.click();
		Thread.sleep(2000);
		cart_checkout.click();
		return driver.getCurrentUrl().equals("http://demo.spreecommerce.org/checkout");
	}
	
	public boolean cartPayCheck() throws InterruptedException {
		Thread.sleep(2000);
		cartCheck.click();
		Thread.sleep(2000);
		saveAndContinue.click();
		Thread.sleep(2000);
		return validOrderTitle.isDisplayed();
	}
}
