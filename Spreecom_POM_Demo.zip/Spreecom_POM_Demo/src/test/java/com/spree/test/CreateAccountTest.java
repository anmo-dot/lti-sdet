package com.spree.test;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import com.spree.pages.CreateAccount;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateAccountTest {
	WebDriver driver;
	CreateAccount account;
	@Test
	public void fulltest() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		ChromeOptions opt = new ChromeOptions();
		driver = new ChromeDriver(opt);
		account = new CreateAccount(driver);
		driver.manage().window().maximize();
		driver.get("http://demo.spreecommerce.org/");
		assertTrue(account.verifyUrl());
		assertTrue(account.clickAccountButton());
		assertTrue(account.createAcctTitleCheck());
		//assertTrue(account.clickSignUpBtn());
		//assertTrue(account.clickLogOut());
		assertTrue(account.clickAlreadyHaveAccountBtn());
		assertTrue(account.allEmptyCredentials());
		assertTrue(account.emptyEmail());
		assertTrue(account.emptyPassword());
		assertTrue(account.confirmPassIncorrect());
	}
}
