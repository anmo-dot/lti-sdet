package com.spree.test;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import com.spree.pages.CheckOut;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CheckOutTest {
	WebDriver driver;
	CheckOut out;
	@Test
	public void fulltest() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		ChromeOptions opt = new ChromeOptions();
		driver = new ChromeDriver(opt);
		out = new CheckOut(driver);
		driver.manage().window().maximize();
		driver.get("http://demo.spreecommerce.org/");
		assertTrue(out.SetUpAccount());
		assertTrue(out.checkPage());
		assertTrue(out.editShippingAddress());
		assertTrue(out.editBillingAddress());
		assertTrue(out.checkAddressSubmit());
		assertTrue(out.chooseDeliverMethod());
		assertTrue(out.checkDeliverySubmit());
		assertTrue(out.checkPaymentSubmit());
		assertTrue(out.checkConfirmSubmit());
		assertTrue(out.cartClick());
		assertTrue(out.cartPayCheck());
		//assertTrue(out.completeCheckPayment());	
	}
}
	
